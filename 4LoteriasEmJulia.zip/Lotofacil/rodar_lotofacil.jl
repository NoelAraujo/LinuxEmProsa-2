using Distributed
addprocs(7)

@everywhere begin
    using DelimitedFiles
    using StatsBase
    using LinearAlgebra
    using Statistics
    # ----------------- DEFINIÇÕES DAS FUNÇÕES----------------
    function contar_acertos(cartela, sorteio)
        sum(diff(sort(vcat(cartela, sorteio)[:])) .== 0)
    end

    function fazer_estatisticas(fechamento, resultados)

        qtd_sorteios = size(resultados,1)
        qtd_cartelas = size(fechamento,1)
        acertos = zeros(qtd_sorteios, qtd_cartelas)
        N_dezenas = maximum(fechamento)

        for i = 1:qtd_sorteios
            sorteio = @view(resultados[i,:])
            numeros_jogador = sample(1:25, N_dezenas, replace = false)
            bolao = numeros_jogador[fechamento]
            @inbounds for j ∈ 1:qtd_cartelas
                cartela = @view(bolao[j,:])
                # cartela= sample(1:25, 15, replace = false)
                acertos[i,j] = contar_acertos(cartela, sorteio)
                if acertos[i,j]==15
                    println("\t !!! Vc conseguiu ganhar na lotofacil !!!")
                    println("cartela: ", sort(cartela))
                    println("sorteio: ", sort(sorteio))
                end
            end
        end

        tamanho_volante = size(fechamento,2) # 15/16/... numeros por volante
        valores_aposta = [2,32,272,1632]
        valor_volante = valores_aposta[tamanho_volante-14]


        freq_acertos = [sum(acertos[:].==i) for i=11:15]
        valor_premios = [4, 8, 20, 1_500, 300_000]

        retornos = dot(freq_acertos,valor_premios)
        investimentos = qtd_cartelas*qtd_sorteios*valor_volante
        acertos = 1;
        return retornos/investimentos
    end

end

# ----------------- SELECIONO TODOS OS ARQUIVOS  ----------------
# !!!!!!!!!! EDITE AQUI !!!!!!!!!!
caminho = "/caminho/da/pasta/no/seu/PC"

resultados = readdlm("$caminho/loto_facil_1707.csv",',',Int)
resultados = resultados[end:-1:1,:]

todos_arquivos = readdir("$caminho/CSV")


# ---------------- VERIFICO O RETORNO DE TODOS OS FECHAMENTOS -----------------
clearconsole()
max_repeticao = 25
@progress for arquivo ∈ todos_arquivos
    println("-------------")
    println("Arquivo: ", arquivo)
    fechamento = readdlm("$caminho/CSV/$arquivo",',',Int)
    @time razao = pmap( r->fazer_estatisticas(fechamento, resultados), 1:max_repeticao )
    println("media: ", round(100*median(razao),digits=2)," ± ", round( 100*std(razao),digits=2))
end

GC.gc()
