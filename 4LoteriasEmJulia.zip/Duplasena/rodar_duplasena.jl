using Distributed
addprocs(7)

@everywhere begin
    using DelimitedFiles
    using StatsBase
    using LinearAlgebra
    using Statistics
    # ----------------- DEFINIÇÕES DAS FUNÇÕES----------------
    function contar_acertos(cartela, sorteio)
        sum(diff(sort(vcat(cartela, sorteio)[:])) .== 0)
    end

    function fazer_estatisticas(fechamento, resultados)

        qtd_sorteios = size(resultados,1)
        qtd_cartelas = size(fechamento,1)
        acertos1 = zeros(qtd_sorteios, qtd_cartelas)
        acertos2 = zeros(qtd_sorteios, qtd_cartelas)
        N_dezenas = maximum(fechamento)

        for i = 1:qtd_sorteios
            sorteio1 = @view(resultados[i,1:6])
            sorteio2 = @view(resultados[i,7:12])
            numeros_jogador = sample(1:50, N_dezenas, replace = false)
            bolao = numeros_jogador[fechamento]
            @inbounds for j ∈ 1:qtd_cartelas
                cartela = @view(bolao[j,:])
                # cartela= sample(1:50, 6, replace = false) # para testar o caso aleatorio
                acertos1[i,j] = contar_acertos(cartela, sorteio1)
                acertos2[i,j] = contar_acertos(cartela, sorteio2)
                if acertos1[i,j]==6 || acertos2[i,j]==6
                    println("\t !!! Vc conseguiu ganhar na duplasena !!!")
                    println("cartela: ", sort(cartela))
                    println("sorteio1: ", sort(sorteio1))
                    println("sorteio2: ", sort(sorteio2))
                end
            end
        end

        acertos = vcat(acertos1,acertos2)

        tamanho_volante = size(fechamento,2) # 6/7/... numeros por volante
        valores_aposta = [2, 14, 56, 168, 420, 924, 1_848, 3_432, 6_006,10_010]
        valor_volante = valores_aposta[tamanho_volante-5]

        freq_acertos = [sum(acertos[:].==i) for i=0:6]
        valor_premios = [0, 0, 0, 2, 70, 4_000, 1_000_000]

        retornos = dot(freq_acertos,valor_premios)
        investimentos = length(acertos[:])*valor_volante
        acertos1 = acertos2 = acertos = 1
        return retornos/investimentos
    end

end

# ----------------- SELECIONO TODOS OS ARQUIVOS  ----------------
# !!!!!!!!!! EDITE AQUI !!!!!!!!!!
caminho = "/caminho/da/pasta/no/seu/PC"


resultados = readdlm("$caminho/dupla_sena_1843.csv",',',Int)
resultados = resultados[end:-1:1,:]

todos_arquivos = readdir("$caminho/CSV")

# ---------------- VERIFICO O RETORNO DE TODOS OS FECHAMENTOS -----------------
clearconsole()
max_repeticao = 25
@progress for arquivo ∈ todos_arquivos
    println("-------------")
    println("Arquivo: ", arquivo)
    fechamento = readdlm("$caminho/CSV/$arquivo",',',Int)
    @time razao = pmap( r->fazer_estatisticas(fechamento, resultados), 1:max_repeticao )
    println("media: ", round(100*median(razao),digits=2)," ± ", round( 100*std(razao),digits=2))
end

GC.gc()
