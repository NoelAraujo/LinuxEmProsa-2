using Distributed
addprocs(7)

@everywhere begin
    using DelimitedFiles
    using StatsBase
    using LinearAlgebra
    using Statistics
    # ----------------- DEFINIÇÕES DAS FUNÇÕES----------------
    function contar_acertos(cartela, sorteio)
        sum(diff(sort(vcat(cartela, sorteio)[:])) .== 0)
    end

    function fazer_estatisticas(fechamento, resultados)

        qtd_sorteios = size(resultados,1)
        qtd_cartelas = size(fechamento,1)
        acertos = zeros(qtd_sorteios, qtd_cartelas)
        N_dezenas = maximum(fechamento)
        for i = 1:qtd_sorteios
            sorteio = @view(resultados[i,:])
            numeros_jogador = sample(1:80, N_dezenas, replace = false)
            bolao = numeros_jogador[fechamento]
            @inbounds for j ∈ 1:qtd_cartelas
                cartela = @view(bolao[j,:])
                # cartela= sample(1:80, 5, replace = false)
                acertos[i,j] = contar_acertos(cartela, sorteio)
                if acertos[i,j]==5
                    println("\t !!! Vc conseguiu ganhar na quina !!!")
                    println("cartela: ", sort(cartela))
                    println("sorteio: ", sort(sorteio))
                end
            end
        end
        tamanho_volante = size(fechamento,2)
        valores_aposta = [1.5, 9, 31.5, 84, 189, 378, 693, 1_188, 1_930.50, 3_003, 4_504.50]
        valor_volante = valores_aposta[tamanho_volante-4]

        freq_acertos = [sum(acertos[:].==i) for i=0:5]
        valor_premios = [0, 0, 3, 100, 8_000, 1_000_000]

        retornos = dot(freq_acertos,valor_premios)
        investimentos = qtd_cartelas*qtd_sorteios*valor_volante
        acertos = 1;
        return retornos/investimentos
    end

end

# ----------------- SELECIONO TODOS OS ARQUIVOS  ----------------
# !!!!!!!!!! EDITE AQUI !!!!!!!!!!
caminho = "/caminho/da/pasta/no/seu/PC"


resultados = readdlm("$caminho/quina_4783.csv",',',Int)
resultados = resultados[end:-1:1,:]

todos_arquivos = readdir("$caminho/CSV")


# ---------------- VERIFICO O RETORNO DE TODOS OS FECHAMENTOS -----------------
clearconsole()
max_repeticao = 25
@progress for arquivo ∈ todos_arquivos
    println("-------------")
    println("Arquivo: ", arquivo)
    fechamento = readdlm("$caminho/CSV/$arquivo",',',Int)
    @time razao = pmap( r->fazer_estatisticas(fechamento, resultados), 1:max_repeticao )
    println("media: ", round(100*median(razao),digits=2)," ± ", round( 100*std(razao),digits=2))
end

GC.gc()
